************************************************************************
This file is part of a package from:
www.majesticform.com

Free Version
2 January 2022

You are free to use and edit for 
your own use. But you cannot resell
or repackage in any way, and you cannot 
remove the credit link back to majesticform.com
****************************************************************************


Thank you for picking majesticform.com

For details on adding this to your website, please see:

https://www.majesticform.com/form-guides/contact-form-installation-free


Quick guide below:

    1. Open the file: fcf-assets/fcf.config.php
    2. Add your email address to the part highlighted below:
        define('EMAIL_TO', 'your email address in here');
    3. Add your email address (this email address must be known by your hosting environment) to the part highlighted below:
        define('EMAIL_FROM', 'your email address in here');
    4. Save
    5. Add the content of fcf.form.htm to your contact page.
    6. Upload ALL files (including the folder fcf-assets to your website)


More detailed installation details can be found at: 

https://www.majesticform.com/form-guides/contact-form-installation-free



****************************************************************************

If you like the form and want to use it long term, please consider buying a license
Help us keep the website live and the software available by showing your support.
Thank you, Stuart from MajesticForm.com

****************************************************************************